package app;

import static spark.Spark.*;

import service.EventoService;
import service.UsuarioService;
import service.AlimentoService;

public class Aplicacao {
    private static UsuarioService usuarioService = new UsuarioService();
    private static EventoService eventoService = new EventoService();

    private static AlimentoService alimentoService = new AlimentoService();

    public static void main(String[] args) {
        port(6788);

        staticFiles.location("/public");

        post("/usuario/cadastro", (request, response) -> usuarioService.insert(request, response));

        post("/usuario/insert", (request, response) -> usuarioService.insert(request, response));

        get("/usuario/:id", (request, response) -> usuarioService.get(request, response));

        get("/usuario/:token", (request, response) -> {
            String token = request.params(":token");

            String[] tokenPart = token.split("_");

            int tokenType = Integer.parseInt(tokenPart[1]);

            response.redirect("http://localhost:6788/frontEnd/");
            return null;
        });

        get("/usuario/list/:orderby", (request, response) -> usuarioService.getAll(request, response));

        get("/usuario/update/:id", (request, response) -> usuarioService.getToUpdate(request, response));

        post("/usuario/update/:id", (request, response) -> usuarioService.update(request, response));

        get("/usuario/delete/:id", (request, response) -> usuarioService.delete(request, response));

        get("/usuario/delete/:cpf", (request, response) -> usuarioService.delete(request, response));

        post("/evento/insert", (request, response) -> eventoService.insert(request, response));

        get("/evento/:id", (request, response) -> eventoService.get(request, response));

        get("/evento/list/:orderby", (request, response) -> eventoService.getAll(request, response));

        get("/evento/update/:id", (request, response) -> eventoService.getToUpdate(request, response));

        post("/evento/update/:id", (request, response) -> eventoService.update(request, response));

        get("/evento/delete/:id", (request, response) -> eventoService.delete(request, response));

        get("/evento/delete/:id", (request, response) -> eventoService.delete(request, response));

        post("/alimento/insert", (request, response) -> alimentoService.insert(request, response));

        get("/alimento/:id", (request, response) -> alimentoService.get(request, response));

        get("/alimento/list/:orderby", (request, response) -> alimentoService.getAll(request, response));

        get("/alimento/update/:id", (request, response) -> alimentoService.getToUpdate(request, response));

        post("/alimento/update/:id", (request, response) -> alimentoService.update(request, response));

        get("/alimento/delete/:id", (request, response) -> alimentoService.delete(request, response));

        get("/alimento/delete/:id", (request, response) -> alimentoService.delete(request, response));

    }
}