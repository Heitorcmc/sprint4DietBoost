package model;

public class Profissional extends Usuario {
    private String especializacao;
    public Profissional() {
        especializacao = "";
    }
    public Profissional (String especializacao) {
        setEspecializacao(especializacao);
    }
    public String getEspecializacao() {
        return especializacao;
    }
    public void setEspecializacao (String especializacao) {
        this.especializacao = especializacao;
    }

    public String toString() {
        return "Usuario: " + nome + "   Email: " + email + "   Telefone: " + telefone + "   Cidade: "
                + cidade  + "   Assinatura: " + assinatura + "   CPF: " + cpf;
    }

    @Override
    public boolean equals(Object obj) {
        return (this.getCpf() == ((Usuario) obj).getCpf());
    }
}

