package model;

import java.util.Date;

public class Evento {
    public int id;
    public String nome;
    public String data;

    public Evento() {
        nome = "";
        data = null;
    }

    public Evento(String nome, String data, int id) {
        setId(id);
        setNome(nome);
        setData(data);
    }

    private void setId(int id) { this.id = id; }

    public int getId() { return id; }
    public String getNome() {
        return nome;
    }
    public void setNome (String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }
    public void setData(String data) { this.data = data; }


    /**
     * Método sobreposto da classe Object. É executado quando um objeto precisa
     * ser exibido na forma de String.
     */

    @Override
    public String toString() {
        return "Id: " + id + "   Evento: " + nome + "   Data: " + data;
    }

    @Override
    public boolean equals(Object obj) {
        return (this.getId() == ((Evento) obj).getId());
    }
}
