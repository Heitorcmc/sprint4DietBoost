package dao;

import model.Evento;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class EventoDAO extends DAO {
	public EventoDAO() {
		super();
		conectar();
	}


	public void finalize() {
		close();
	}


	public boolean insert(Evento evento) {
		boolean status = false;
		try {
			String sql = "INSERT INTO evento (nome, data) "
					+ "VALUES ('" + evento.getNome() + "', '"
					+ evento.getData() + "');";
			PreparedStatement st = conexao.prepareStatement(sql);
			st.executeUpdate();
			st.close();
			status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}


	public Evento get(int id) {
		Evento evento = null;

		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM evento WHERE id= " + id;
			ResultSet rs = st.executeQuery(sql);
			if(rs.next()){
				evento = new Evento(rs.getString("nome"), rs.getString("data"), rs.getInt("id"));
//	        			               rs.getTimestamp("datafabricacao").toLocalDateTime(),
//	        			               rs.getDate("datavalidade").toLocalDate());
			}
			st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return evento;
	}


	public List<Evento> get() {
		return get("");
	}


	public List<Evento> getOrderByID() {
		return get("id");
	}


	public List<Evento> getOrderByNome() {
		return get("nome");
	}


	public List<Evento> getOrderByData() {
		return get("data");
	}


	private List<Evento> get(String orderBy) {
		List<Evento> eventos = new ArrayList<Evento>();

		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM evento" + ((orderBy.trim().length() == 0) ? "" : (" ORDER BY " + orderBy));
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				Evento a = new Evento (rs.getString("nome"), rs.getString("data"), rs.getInt("id"));
				eventos.add(a);
			}
			st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return eventos;
	}


	public boolean update(Evento evento) {
		boolean status = false;
		try {
			String sql = "UPDATE evento SET nome = '" + evento.getNome() + "', "
					   + "data = '" + evento.getData()
					   + "' WHERE id = " + evento.getId();
			PreparedStatement st = conexao.prepareStatement(sql);
			st.executeUpdate();
			st.close();
			status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}


	public boolean delete(int id) {
		boolean status = false;
		try {
			Statement st = conexao.createStatement();
			st.executeUpdate("DELETE FROM evento WHERE id = " + id);
			st.close();
			status = true;
		} catch (SQLException u) {
			throw new RuntimeException(u);
		}
		return status;
	}
}